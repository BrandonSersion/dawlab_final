﻿namespace WindowsFormsApp1
{
    partial class Preferences
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Preferences));
            this.horrorGrpBox = new System.Windows.Forms.GroupBox();
            this.radioHorrorSD = new System.Windows.Forms.RadioButton();
            this.radioHorrorDislike = new System.Windows.Forms.RadioButton();
            this.radioHorrorNeutral = new System.Windows.Forms.RadioButton();
            this.radioHorrorLike = new System.Windows.Forms.RadioButton();
            this.radioHorrorSL = new System.Windows.Forms.RadioButton();
            this.likeHeader = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioDramaSD = new System.Windows.Forms.RadioButton();
            this.radioDramaDislike = new System.Windows.Forms.RadioButton();
            this.radioDramaNeutral = new System.Windows.Forms.RadioButton();
            this.radioDramaLike = new System.Windows.Forms.RadioButton();
            this.radioDramaSL = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radioComedySD = new System.Windows.Forms.RadioButton();
            this.radioComedyDislike = new System.Windows.Forms.RadioButton();
            this.radioComedyNeutral = new System.Windows.Forms.RadioButton();
            this.radioComedyLike = new System.Windows.Forms.RadioButton();
            this.radioComedySL = new System.Windows.Forms.RadioButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.radioRomanceSD = new System.Windows.Forms.RadioButton();
            this.radioRomanceDislike = new System.Windows.Forms.RadioButton();
            this.radioRomanceNeutral = new System.Windows.Forms.RadioButton();
            this.radioRomanceLike = new System.Windows.Forms.RadioButton();
            this.radioRomanceSL = new System.Windows.Forms.RadioButton();
            this.submitButton = new System.Windows.Forms.Button();
            this.closeButton = new System.Windows.Forms.Button();
            this.logoLabel = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.horrorGrpBox.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // horrorGrpBox
            // 
            this.horrorGrpBox.Controls.Add(this.radioHorrorSD);
            this.horrorGrpBox.Controls.Add(this.radioHorrorDislike);
            this.horrorGrpBox.Controls.Add(this.radioHorrorNeutral);
            this.horrorGrpBox.Controls.Add(this.radioHorrorLike);
            this.horrorGrpBox.Controls.Add(this.radioHorrorSL);
            this.horrorGrpBox.Location = new System.Drawing.Point(332, 158);
            this.horrorGrpBox.Margin = new System.Windows.Forms.Padding(6);
            this.horrorGrpBox.Name = "horrorGrpBox";
            this.horrorGrpBox.Padding = new System.Windows.Forms.Padding(6);
            this.horrorGrpBox.Size = new System.Drawing.Size(1134, 73);
            this.horrorGrpBox.TabIndex = 0;
            this.horrorGrpBox.TabStop = false;
            // 
            // radioHorrorSD
            // 
            this.radioHorrorSD.AutoSize = true;
            this.radioHorrorSD.Location = new System.Drawing.Point(928, 29);
            this.radioHorrorSD.Margin = new System.Windows.Forms.Padding(6);
            this.radioHorrorSD.Name = "radioHorrorSD";
            this.radioHorrorSD.Size = new System.Drawing.Size(27, 26);
            this.radioHorrorSD.TabIndex = 4;
            this.radioHorrorSD.TabStop = true;
            this.radioHorrorSD.UseVisualStyleBackColor = true;
            // 
            // radioHorrorDislike
            // 
            this.radioHorrorDislike.AutoSize = true;
            this.radioHorrorDislike.Location = new System.Drawing.Point(714, 29);
            this.radioHorrorDislike.Margin = new System.Windows.Forms.Padding(6);
            this.radioHorrorDislike.Name = "radioHorrorDislike";
            this.radioHorrorDislike.Size = new System.Drawing.Size(27, 26);
            this.radioHorrorDislike.TabIndex = 3;
            this.radioHorrorDislike.TabStop = true;
            this.radioHorrorDislike.UseVisualStyleBackColor = true;
            // 
            // radioHorrorNeutral
            // 
            this.radioHorrorNeutral.AutoSize = true;
            this.radioHorrorNeutral.Location = new System.Drawing.Point(504, 29);
            this.radioHorrorNeutral.Margin = new System.Windows.Forms.Padding(6);
            this.radioHorrorNeutral.Name = "radioHorrorNeutral";
            this.radioHorrorNeutral.Size = new System.Drawing.Size(27, 26);
            this.radioHorrorNeutral.TabIndex = 2;
            this.radioHorrorNeutral.TabStop = true;
            this.radioHorrorNeutral.UseVisualStyleBackColor = true;
            // 
            // radioHorrorLike
            // 
            this.radioHorrorLike.AutoSize = true;
            this.radioHorrorLike.Location = new System.Drawing.Point(302, 29);
            this.radioHorrorLike.Margin = new System.Windows.Forms.Padding(6);
            this.radioHorrorLike.Name = "radioHorrorLike";
            this.radioHorrorLike.Size = new System.Drawing.Size(27, 26);
            this.radioHorrorLike.TabIndex = 1;
            this.radioHorrorLike.TabStop = true;
            this.radioHorrorLike.UseVisualStyleBackColor = true;
            // 
            // radioHorrorSL
            // 
            this.radioHorrorSL.AutoSize = true;
            this.radioHorrorSL.Location = new System.Drawing.Point(100, 29);
            this.radioHorrorSL.Margin = new System.Windows.Forms.Padding(6);
            this.radioHorrorSL.Name = "radioHorrorSL";
            this.radioHorrorSL.Size = new System.Drawing.Size(27, 26);
            this.radioHorrorSL.TabIndex = 0;
            this.radioHorrorSL.TabStop = true;
            this.radioHorrorSL.UseVisualStyleBackColor = true;
            // 
            // likeHeader
            // 
            this.likeHeader.BackColor = System.Drawing.Color.LightGray;
            this.likeHeader.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.likeHeader.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.likeHeader.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.likeHeader.Location = new System.Drawing.Point(332, 96);
            this.likeHeader.Margin = new System.Windows.Forms.Padding(6);
            this.likeHeader.Name = "likeHeader";
            this.likeHeader.Size = new System.Drawing.Size(1130, 47);
            this.likeHeader.TabIndex = 1;
            this.likeHeader.Text = "  Strongly Like     Like           Neutral          Dislike     Strongly Dislike";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.LightGray;
            this.textBox1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.textBox1.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.textBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.textBox1.Location = new System.Drawing.Point(24, 96);
            this.textBox1.Margin = new System.Windows.Forms.Padding(6);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(276, 391);
            this.textBox1.TabIndex = 2;
            this.textBox1.Text = "Categories  \r\n\r\nHorror\r\n\r\nDrama\r\n\r\nComedy\r\n\r\nRomance";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioDramaSD);
            this.groupBox1.Controls.Add(this.radioDramaDislike);
            this.groupBox1.Controls.Add(this.radioDramaNeutral);
            this.groupBox1.Controls.Add(this.radioDramaLike);
            this.groupBox1.Controls.Add(this.radioDramaSL);
            this.groupBox1.Location = new System.Drawing.Point(332, 242);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(6);
            this.groupBox1.Size = new System.Drawing.Size(1134, 73);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            // 
            // radioDramaSD
            // 
            this.radioDramaSD.AutoSize = true;
            this.radioDramaSD.Location = new System.Drawing.Point(928, 29);
            this.radioDramaSD.Margin = new System.Windows.Forms.Padding(6);
            this.radioDramaSD.Name = "radioDramaSD";
            this.radioDramaSD.Size = new System.Drawing.Size(27, 26);
            this.radioDramaSD.TabIndex = 4;
            this.radioDramaSD.TabStop = true;
            this.radioDramaSD.UseVisualStyleBackColor = true;
            // 
            // radioDramaDislike
            // 
            this.radioDramaDislike.AutoSize = true;
            this.radioDramaDislike.Location = new System.Drawing.Point(714, 29);
            this.radioDramaDislike.Margin = new System.Windows.Forms.Padding(6);
            this.radioDramaDislike.Name = "radioDramaDislike";
            this.radioDramaDislike.Size = new System.Drawing.Size(27, 26);
            this.radioDramaDislike.TabIndex = 3;
            this.radioDramaDislike.TabStop = true;
            this.radioDramaDislike.UseVisualStyleBackColor = true;
            // 
            // radioDramaNeutral
            // 
            this.radioDramaNeutral.AutoSize = true;
            this.radioDramaNeutral.Location = new System.Drawing.Point(504, 29);
            this.radioDramaNeutral.Margin = new System.Windows.Forms.Padding(6);
            this.radioDramaNeutral.Name = "radioDramaNeutral";
            this.radioDramaNeutral.Size = new System.Drawing.Size(27, 26);
            this.radioDramaNeutral.TabIndex = 2;
            this.radioDramaNeutral.TabStop = true;
            this.radioDramaNeutral.UseVisualStyleBackColor = true;
            // 
            // radioDramaLike
            // 
            this.radioDramaLike.AutoSize = true;
            this.radioDramaLike.Location = new System.Drawing.Point(302, 29);
            this.radioDramaLike.Margin = new System.Windows.Forms.Padding(6);
            this.radioDramaLike.Name = "radioDramaLike";
            this.radioDramaLike.Size = new System.Drawing.Size(27, 26);
            this.radioDramaLike.TabIndex = 1;
            this.radioDramaLike.TabStop = true;
            this.radioDramaLike.UseVisualStyleBackColor = true;
            // 
            // radioDramaSL
            // 
            this.radioDramaSL.AutoSize = true;
            this.radioDramaSL.Location = new System.Drawing.Point(100, 29);
            this.radioDramaSL.Margin = new System.Windows.Forms.Padding(6);
            this.radioDramaSL.Name = "radioDramaSL";
            this.radioDramaSL.Size = new System.Drawing.Size(27, 26);
            this.radioDramaSL.TabIndex = 0;
            this.radioDramaSL.TabStop = true;
            this.radioDramaSL.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radioComedySD);
            this.groupBox2.Controls.Add(this.radioComedyDislike);
            this.groupBox2.Controls.Add(this.radioComedyNeutral);
            this.groupBox2.Controls.Add(this.radioComedyLike);
            this.groupBox2.Controls.Add(this.radioComedySL);
            this.groupBox2.Location = new System.Drawing.Point(332, 308);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(6);
            this.groupBox2.Size = new System.Drawing.Size(1134, 73);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            // 
            // radioComedySD
            // 
            this.radioComedySD.AutoSize = true;
            this.radioComedySD.Location = new System.Drawing.Point(928, 29);
            this.radioComedySD.Margin = new System.Windows.Forms.Padding(6);
            this.radioComedySD.Name = "radioComedySD";
            this.radioComedySD.Size = new System.Drawing.Size(27, 26);
            this.radioComedySD.TabIndex = 4;
            this.radioComedySD.TabStop = true;
            this.radioComedySD.UseVisualStyleBackColor = true;
            // 
            // radioComedyDislike
            // 
            this.radioComedyDislike.AutoSize = true;
            this.radioComedyDislike.Location = new System.Drawing.Point(714, 29);
            this.radioComedyDislike.Margin = new System.Windows.Forms.Padding(6);
            this.radioComedyDislike.Name = "radioComedyDislike";
            this.radioComedyDislike.Size = new System.Drawing.Size(27, 26);
            this.radioComedyDislike.TabIndex = 3;
            this.radioComedyDislike.TabStop = true;
            this.radioComedyDislike.UseVisualStyleBackColor = true;
            // 
            // radioComedyNeutral
            // 
            this.radioComedyNeutral.AutoSize = true;
            this.radioComedyNeutral.Location = new System.Drawing.Point(504, 29);
            this.radioComedyNeutral.Margin = new System.Windows.Forms.Padding(6);
            this.radioComedyNeutral.Name = "radioComedyNeutral";
            this.radioComedyNeutral.Size = new System.Drawing.Size(27, 26);
            this.radioComedyNeutral.TabIndex = 2;
            this.radioComedyNeutral.TabStop = true;
            this.radioComedyNeutral.UseVisualStyleBackColor = true;
            // 
            // radioComedyLike
            // 
            this.radioComedyLike.AutoSize = true;
            this.radioComedyLike.Location = new System.Drawing.Point(302, 29);
            this.radioComedyLike.Margin = new System.Windows.Forms.Padding(6);
            this.radioComedyLike.Name = "radioComedyLike";
            this.radioComedyLike.Size = new System.Drawing.Size(27, 26);
            this.radioComedyLike.TabIndex = 1;
            this.radioComedyLike.TabStop = true;
            this.radioComedyLike.UseVisualStyleBackColor = true;
            // 
            // radioComedySL
            // 
            this.radioComedySL.AutoSize = true;
            this.radioComedySL.Location = new System.Drawing.Point(100, 29);
            this.radioComedySL.Margin = new System.Windows.Forms.Padding(6);
            this.radioComedySL.Name = "radioComedySL";
            this.radioComedySL.Size = new System.Drawing.Size(27, 26);
            this.radioComedySL.TabIndex = 0;
            this.radioComedySL.TabStop = true;
            this.radioComedySL.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.radioRomanceSD);
            this.groupBox3.Controls.Add(this.radioRomanceDislike);
            this.groupBox3.Controls.Add(this.radioRomanceNeutral);
            this.groupBox3.Controls.Add(this.radioRomanceLike);
            this.groupBox3.Controls.Add(this.radioRomanceSL);
            this.groupBox3.Location = new System.Drawing.Point(332, 392);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(6);
            this.groupBox3.Size = new System.Drawing.Size(1134, 81);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            // 
            // radioRomanceSD
            // 
            this.radioRomanceSD.AutoSize = true;
            this.radioRomanceSD.Location = new System.Drawing.Point(928, 29);
            this.radioRomanceSD.Margin = new System.Windows.Forms.Padding(6);
            this.radioRomanceSD.Name = "radioRomanceSD";
            this.radioRomanceSD.Size = new System.Drawing.Size(27, 26);
            this.radioRomanceSD.TabIndex = 4;
            this.radioRomanceSD.TabStop = true;
            this.radioRomanceSD.UseVisualStyleBackColor = true;
            // 
            // radioRomanceDislike
            // 
            this.radioRomanceDislike.AutoSize = true;
            this.radioRomanceDislike.Location = new System.Drawing.Point(714, 29);
            this.radioRomanceDislike.Margin = new System.Windows.Forms.Padding(6);
            this.radioRomanceDislike.Name = "radioRomanceDislike";
            this.radioRomanceDislike.Size = new System.Drawing.Size(27, 26);
            this.radioRomanceDislike.TabIndex = 3;
            this.radioRomanceDislike.TabStop = true;
            this.radioRomanceDislike.UseVisualStyleBackColor = true;
            // 
            // radioRomanceNeutral
            // 
            this.radioRomanceNeutral.AutoSize = true;
            this.radioRomanceNeutral.Location = new System.Drawing.Point(504, 29);
            this.radioRomanceNeutral.Margin = new System.Windows.Forms.Padding(6);
            this.radioRomanceNeutral.Name = "radioRomanceNeutral";
            this.radioRomanceNeutral.Size = new System.Drawing.Size(27, 26);
            this.radioRomanceNeutral.TabIndex = 2;
            this.radioRomanceNeutral.TabStop = true;
            this.radioRomanceNeutral.UseVisualStyleBackColor = true;
            // 
            // radioRomanceLike
            // 
            this.radioRomanceLike.AutoSize = true;
            this.radioRomanceLike.Location = new System.Drawing.Point(302, 29);
            this.radioRomanceLike.Margin = new System.Windows.Forms.Padding(6);
            this.radioRomanceLike.Name = "radioRomanceLike";
            this.radioRomanceLike.Size = new System.Drawing.Size(27, 26);
            this.radioRomanceLike.TabIndex = 1;
            this.radioRomanceLike.TabStop = true;
            this.radioRomanceLike.UseVisualStyleBackColor = true;
            // 
            // radioRomanceSL
            // 
            this.radioRomanceSL.AutoSize = true;
            this.radioRomanceSL.Location = new System.Drawing.Point(100, 29);
            this.radioRomanceSL.Margin = new System.Windows.Forms.Padding(6);
            this.radioRomanceSL.Name = "radioRomanceSL";
            this.radioRomanceSL.Size = new System.Drawing.Size(27, 26);
            this.radioRomanceSL.TabIndex = 0;
            this.radioRomanceSL.TabStop = true;
            this.radioRomanceSL.UseVisualStyleBackColor = true;
            // 
            // submitButton
            // 
            this.submitButton.BackColor = System.Drawing.Color.LightGray;
            this.submitButton.Font = new System.Drawing.Font("Century Gothic", 7.875F);
            this.submitButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.submitButton.Location = new System.Drawing.Point(568, 19);
            this.submitButton.Margin = new System.Windows.Forms.Padding(6);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(296, 44);
            this.submitButton.TabIndex = 6;
            this.submitButton.Text = "Submit Prefernces";
            this.submitButton.UseVisualStyleBackColor = false;
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // closeButton
            // 
            this.closeButton.Font = new System.Drawing.Font("Century Gothic", 7.875F);
            this.closeButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.closeButton.Location = new System.Drawing.Point(876, 19);
            this.closeButton.Margin = new System.Windows.Forms.Padding(6);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(308, 44);
            this.closeButton.TabIndex = 11;
            this.closeButton.Text = "Close";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // logoLabel
            // 
            this.logoLabel.AutoSize = true;
            this.logoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.logoLabel.Location = new System.Drawing.Point(576, 540);
            this.logoLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.logoLabel.Name = "logoLabel";
            this.logoLabel.Size = new System.Drawing.Size(267, 48);
            this.logoLabel.TabIndex = 17;
            this.logoLabel.Text = "Powered By:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::WindowsFormsApp1.Properties.Resources.Dawlab_classic_with_background;
            this.pictureBox1.Location = new System.Drawing.Point(876, 537);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(6);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(228, 52);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 16;
            this.pictureBox1.TabStop = false;
            // 
            // Preferences
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1500, 610);
            this.Controls.Add(this.logoLabel);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.submitButton);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.likeHeader);
            this.Controls.Add(this.horrorGrpBox);
            this.ForeColor = System.Drawing.Color.Red;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "Preferences";
            this.Text = "Zetflix";
            this.Load += new System.EventHandler(this.Form1_Load_1);
            this.horrorGrpBox.ResumeLayout(false);
            this.horrorGrpBox.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox horrorGrpBox;
        private System.Windows.Forms.RadioButton radioHorrorSD;
        private System.Windows.Forms.RadioButton radioHorrorDislike;
        private System.Windows.Forms.RadioButton radioHorrorNeutral;
        private System.Windows.Forms.RadioButton radioHorrorLike;
        private System.Windows.Forms.RadioButton radioHorrorSL;
        private System.Windows.Forms.TextBox likeHeader;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radioDramaSD;
        private System.Windows.Forms.RadioButton radioDramaDislike;
        private System.Windows.Forms.RadioButton radioDramaNeutral;
        private System.Windows.Forms.RadioButton radioDramaLike;
        private System.Windows.Forms.RadioButton radioDramaSL;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton radioComedySD;
        private System.Windows.Forms.RadioButton radioComedyDislike;
        private System.Windows.Forms.RadioButton radioComedyNeutral;
        private System.Windows.Forms.RadioButton radioComedyLike;
        private System.Windows.Forms.RadioButton radioComedySL;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton radioRomanceSD;
        private System.Windows.Forms.RadioButton radioRomanceDislike;
        private System.Windows.Forms.RadioButton radioRomanceNeutral;
        private System.Windows.Forms.RadioButton radioRomanceLike;
        private System.Windows.Forms.RadioButton radioRomanceSL;
        private System.Windows.Forms.Button submitButton;
        private System.Windows.Forms.Button closeButton;
        private System.Windows.Forms.Label logoLabel;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

